
<?php $__env->startSection('dashboard'); ?>
    <section>
        <form ction="/addblogPage" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <!-- Main Heading -->
            <div>
                <label for="main_heading">Main Heading</label>
                <input type="text" id="main_heading" name="main_heading" required>
            </div>

            <!-- Main Image -->
            <div>
                <label for="main_image">Main Image</label>
                <input type="file" id="main_image" name="main_image" accept="image/*" required>
            </div>

            <!-- Subheadings, Descriptions, and Images -->
            <div id="subheading-section">
                <div class="subheading-group">
                    <label for="subheading[]">Subheading</label>
                    <input type="text" name="subheading[]" required>

                    <label for="description[]">Description</label>
                    <textarea name="description[]" rows="3" required></textarea>

                    <label for="sub_image[]">Sub Image</label>
                    <input type="file" name="sub_image[]" accept="image/*">
                </div>
            </div>

            <button type="button" id="add-subheading">Add Another Subheading</button>

            <div>
                <button type="submit">Submit</button>
            </div>
        </form>

        
        <?php if(!isset($blogs)): ?>
            <p>Blogs variable is not set.</p>
        <?php else: ?>
            <?php if($blogs->isEmpty()): ?>
                <p>No blog details available.</p>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Blog ID</th>
                            <th>Main Heading</th>
                            <th>Main Image</th>
                            <th>Subheading</th>
                            <th>Description</th>
                            <th>Sub Image</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $blog->subContents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subContent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($blog->id); ?></td>
                                    <td><?php echo e($blog->main_heading); ?></td>
                                    <td><img src="<?php echo e($blog->main_image); ?>" alt="main-image"></td>
                                    <td><?php echo e($subContent->subheading); ?></td>
                                    <td><?php echo e($subContent->description); ?></td>
                                    <td>
                                        <?php if($subContent->sub_image): ?>
                                            <img src="<?php echo e($subContent->sub_image); ?>" alt="sub-image">
                                        <?php else: ?>
                                            No image
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endif; ?>
        <?php endif; ?>
    </section>

    <script>
        document.getElementById('add-subheading').addEventListener('click', function() {
            var subheadingSection = document.getElementById('subheading-section');
            var newSubheadingGroup = document.createElement('div');
            newSubheadingGroup.classList.add('subheading-group');

            newSubheadingGroup.innerHTML = `
        <label for="subheading[]">Subheading</label>
        <input type="text" name="subheading[]" required>

        <label for="description[]">Description</label>
        <textarea name="description[]" rows="3" required></textarea>

        <label for="sub_image[]">Sub Image</label>
        <input type="file" name="sub_image[]" accept="image/*">
    `;

            subheadingSection.appendChild(newSubheadingGroup);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\element data\new-web\web\ec\resources\views/dashboard/addblog.blade.php ENDPATH**/ ?>