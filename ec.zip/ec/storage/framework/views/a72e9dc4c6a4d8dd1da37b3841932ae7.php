

<?php $__env->startSection('dashboard'); ?>
    <?php if(!isset($contacts)): ?>
        <p>Contacts variable is not set.</p>
    <?php else: ?>
        <?php if($contacts->isEmpty()): ?>
            <p>No contact details available.</p>
        <?php else: ?>
            <table class="contactInfo-table">
                <thead class="contactInfo-thead">
                    <tr>
                        <th class="contactInfo-th">Id</th>
                        <th class="contactInfo-th">Name</th>
                        <th class="contactInfo-th">Company</th>
                        <th class="contactInfo-th">Email</th>
                        <th class="contactInfo-th">Phone</th>
                        <th class="contactInfo-th">Service</th>
                        <th class="contactInfo-th">Budget</th>
                        <th class="contactInfo-th">Project Description</th>
                        
                    </tr>
                </thead>
                <tbody class="contactInfo-tbody">
                    <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="contactInfo-tr">
                            <td class="contactInfo-td"><?php echo e($contact->id); ?></td>
                            <td class="contactInfo-td"><?php echo e($contact->contact_name); ?></td>
                            <td class="contactInfo-td"><?php echo e($contact->contact_company); ?></td>
                            <td class="contactInfo-td"><?php echo e($contact->contact_email); ?></td>
                            <td class="contactInfo-td"><?php echo e($contact->contact_phone); ?></td>
                            <td class="contactInfo-td"><?php echo e($contact->contact_service); ?></td>
                            <td class="contactInfo-td"><?php echo e($contact->contact_budget); ?></td>
                            <td class="contactInfo-td"><?php echo e($contact->contact_Description); ?></td>
                            
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\element data\new-web\web\ec\resources\views/dashboard/contactinfo.blade.php ENDPATH**/ ?>